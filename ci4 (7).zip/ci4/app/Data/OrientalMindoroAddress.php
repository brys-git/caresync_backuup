<?php

/*
 * Oriental Mindoro city/municipality + barangay list (PSA PSGC, 2025 Q2).
 * 15 LGUs, 426 barangays. Generated file: do not edit by hand.
 * Place at app/Data/OrientalMindoroAddress.php and load with:
 *   $data = require APPPATH . 'Data/OrientalMindoroAddress.php';
 */

return [
    'province' => 'Oriental Mindoro',
    'province_code' => '1705200000',
    'region' => 'MIMAROPA',
    'source' => 'PSA PSGC 2025 Q2',
    'cities' => [
        [
            'code' => '1705201000',
            'old_code' => '175201000',
            'name' => 'Baco',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705201001',
                    'old_code' => '175201001',
                    'name' => 'Alag',
                ],
                [
                    'code' => '1705201002',
                    'old_code' => '175201002',
                    'name' => 'Bangkatan',
                ],
                [
                    'code' => '1705201026',
                    'old_code' => '175201026',
                    'name' => 'Baras',
                ],
                [
                    'code' => '1705201027',
                    'old_code' => '175201027',
                    'name' => 'Bayanan',
                ],
                [
                    'code' => '1705201004',
                    'old_code' => '175201004',
                    'name' => 'Burbuli',
                ],
                [
                    'code' => '1705201005',
                    'old_code' => '175201005',
                    'name' => 'Catwiran I',
                ],
                [
                    'code' => '1705201006',
                    'old_code' => '175201006',
                    'name' => 'Catwiran II',
                ],
                [
                    'code' => '1705201007',
                    'old_code' => '175201007',
                    'name' => 'Dulangan I',
                ],
                [
                    'code' => '1705201008',
                    'old_code' => '175201008',
                    'name' => 'Dulangan II',
                ],
                [
                    'code' => '1705201028',
                    'old_code' => '175201028',
                    'name' => 'Lantuyang',
                ],
                [
                    'code' => '1705201010',
                    'old_code' => '175201010',
                    'name' => 'Lumang Bayan',
                ],
                [
                    'code' => '1705201011',
                    'old_code' => '175201011',
                    'name' => 'Malapad',
                ],
                [
                    'code' => '1705201012',
                    'old_code' => '175201012',
                    'name' => 'Mangangan I',
                ],
                [
                    'code' => '1705201013',
                    'old_code' => '175201013',
                    'name' => 'Mangangan II',
                ],
                [
                    'code' => '1705201014',
                    'old_code' => '175201014',
                    'name' => 'Mayabig',
                ],
                [
                    'code' => '1705201015',
                    'old_code' => '175201015',
                    'name' => 'Pambisan',
                ],
                [
                    'code' => '1705201029',
                    'old_code' => '175201029',
                    'name' => 'Poblacion',
                ],
                [
                    'code' => '1705201016',
                    'old_code' => '175201016',
                    'name' => 'Pulang-Tubig',
                ],
                [
                    'code' => '1705201017',
                    'old_code' => '175201017',
                    'name' => 'Putican-Cabulo',
                ],
                [
                    'code' => '1705201018',
                    'old_code' => '175201018',
                    'name' => 'San Andres',
                ],
                [
                    'code' => '1705201019',
                    'old_code' => '175201019',
                    'name' => 'San Ignacio',
                ],
                [
                    'code' => '1705201020',
                    'old_code' => '175201020',
                    'name' => 'Santa Cruz',
                ],
                [
                    'code' => '1705201021',
                    'old_code' => '175201021',
                    'name' => 'Santa Rosa I',
                ],
                [
                    'code' => '1705201022',
                    'old_code' => '175201022',
                    'name' => 'Santa Rosa II',
                ],
                [
                    'code' => '1705201023',
                    'old_code' => '175201023',
                    'name' => 'Tabon-tabon',
                ],
                [
                    'code' => '1705201024',
                    'old_code' => '175201024',
                    'name' => 'Tagumpay',
                ],
                [
                    'code' => '1705201025',
                    'old_code' => '175201025',
                    'name' => 'Water',
                ],
            ],
        ],
        [
            'code' => '1705202000',
            'old_code' => '175202000',
            'name' => 'Bansud',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705202001',
                    'old_code' => '175202001',
                    'name' => 'Alcadesma',
                ],
                [
                    'code' => '1705202003',
                    'old_code' => '175202003',
                    'name' => 'Bato',
                ],
                [
                    'code' => '1705202004',
                    'old_code' => '175202004',
                    'name' => 'Conrazon',
                ],
                [
                    'code' => '1705202005',
                    'old_code' => '175202005',
                    'name' => 'Malo',
                ],
                [
                    'code' => '1705202006',
                    'old_code' => '175202006',
                    'name' => 'Manihala',
                ],
                [
                    'code' => '1705202007',
                    'old_code' => '175202007',
                    'name' => 'Pag-Asa',
                ],
                [
                    'code' => '1705202008',
                    'old_code' => '175202008',
                    'name' => 'Poblacion',
                ],
                [
                    'code' => '1705202009',
                    'old_code' => '175202009',
                    'name' => 'Proper Bansud',
                ],
                [
                    'code' => '1705202013',
                    'old_code' => '175202013',
                    'name' => 'Proper Tiguisan',
                ],
                [
                    'code' => '1705202010',
                    'old_code' => '175202010',
                    'name' => 'Rosacara',
                ],
                [
                    'code' => '1705202011',
                    'old_code' => '175202011',
                    'name' => 'Salcedo',
                ],
                [
                    'code' => '1705202012',
                    'old_code' => '175202012',
                    'name' => 'Sumagui',
                ],
                [
                    'code' => '1705202014',
                    'old_code' => '175202014',
                    'name' => 'Villa Pag-Asa',
                ],
            ],
        ],
        [
            'code' => '1705203000',
            'old_code' => '175203000',
            'name' => 'Bongabong',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705203001',
                    'old_code' => '175203001',
                    'name' => 'Anilao',
                ],
                [
                    'code' => '1705203033',
                    'old_code' => '175203033',
                    'name' => 'Aplaya',
                ],
                [
                    'code' => '1705203034',
                    'old_code' => '175203034',
                    'name' => 'Bagumbayan I',
                ],
                [
                    'code' => '1705203035',
                    'old_code' => '175203035',
                    'name' => 'Bagumbayan II',
                ],
                [
                    'code' => '1705203002',
                    'old_code' => '175203002',
                    'name' => 'Batangan',
                ],
                [
                    'code' => '1705203003',
                    'old_code' => '175203003',
                    'name' => 'Bukal',
                ],
                [
                    'code' => '1705203004',
                    'old_code' => '175203004',
                    'name' => 'Camantigue',
                ],
                [
                    'code' => '1705203005',
                    'old_code' => '175203005',
                    'name' => 'Carmundo',
                ],
                [
                    'code' => '1705203006',
                    'old_code' => '175203006',
                    'name' => 'Cawayan',
                ],
                [
                    'code' => '1705203007',
                    'old_code' => '175203007',
                    'name' => 'Dayhagan',
                ],
                [
                    'code' => '1705203008',
                    'old_code' => '175203008',
                    'name' => 'Formon',
                ],
                [
                    'code' => '1705203009',
                    'old_code' => '175203009',
                    'name' => 'Hagan',
                ],
                [
                    'code' => '1705203010',
                    'old_code' => '175203010',
                    'name' => 'Hagupit',
                ],
                [
                    'code' => '1705203036',
                    'old_code' => '175203036',
                    'name' => 'Ipil',
                ],
                [
                    'code' => '1705203011',
                    'old_code' => '175203011',
                    'name' => 'Kaligtasan',
                ],
                [
                    'code' => '1705203012',
                    'old_code' => '175203012',
                    'name' => 'Labasan',
                ],
                [
                    'code' => '1705203013',
                    'old_code' => '175203013',
                    'name' => 'Labonan',
                ],
                [
                    'code' => '1705203014',
                    'old_code' => '175203014',
                    'name' => 'Libertad',
                ],
                [
                    'code' => '1705203015',
                    'old_code' => '175203015',
                    'name' => 'Lisap',
                ],
                [
                    'code' => '1705203016',
                    'old_code' => '175203016',
                    'name' => 'Luna',
                ],
                [
                    'code' => '1705203017',
                    'old_code' => '175203017',
                    'name' => 'Malitbog',
                ],
                [
                    'code' => '1705203018',
                    'old_code' => '175203018',
                    'name' => 'Mapang',
                ],
                [
                    'code' => '1705203019',
                    'old_code' => '175203019',
                    'name' => 'Masaguisi',
                ],
                [
                    'code' => '1705203037',
                    'old_code' => '175203037',
                    'name' => 'Mina de Oro',
                ],
                [
                    'code' => '1705203020',
                    'old_code' => '175203020',
                    'name' => 'Morente',
                ],
                [
                    'code' => '1705203021',
                    'old_code' => '175203021',
                    'name' => 'Ogbot',
                ],
                [
                    'code' => '1705203022',
                    'old_code' => '175203022',
                    'name' => 'Orconuma',
                ],
                [
                    'code' => '1705203032',
                    'old_code' => '175203032',
                    'name' => 'Poblacion',
                ],
                [
                    'code' => '1705203023',
                    'old_code' => '175203023',
                    'name' => 'Polusahi',
                ],
                [
                    'code' => '1705203024',
                    'old_code' => '175203024',
                    'name' => 'Sagana',
                ],
                [
                    'code' => '1705203025',
                    'old_code' => '175203025',
                    'name' => 'San Isidro',
                ],
                [
                    'code' => '1705203026',
                    'old_code' => '175203026',
                    'name' => 'San Jose',
                ],
                [
                    'code' => '1705203027',
                    'old_code' => '175203027',
                    'name' => 'San Juan',
                ],
                [
                    'code' => '1705203028',
                    'old_code' => '175203028',
                    'name' => 'Santa Cruz',
                ],
                [
                    'code' => '1705203029',
                    'old_code' => '175203029',
                    'name' => 'Sigange',
                ],
                [
                    'code' => '1705203031',
                    'old_code' => '175203031',
                    'name' => 'Tawas',
                ],
            ],
        ],
        [
            'code' => '1705204000',
            'old_code' => '175204000',
            'name' => 'Bulalacao',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705204001',
                    'old_code' => '175204001',
                    'name' => 'Bagong Sikat',
                ],
                [
                    'code' => '1705204002',
                    'old_code' => '175204002',
                    'name' => 'Balatasan',
                ],
                [
                    'code' => '1705204003',
                    'old_code' => '175204003',
                    'name' => 'Benli',
                ],
                [
                    'code' => '1705204005',
                    'old_code' => '175204005',
                    'name' => 'Cabugao',
                ],
                [
                    'code' => '1705204006',
                    'old_code' => '175204006',
                    'name' => 'Cambunang',
                ],
                [
                    'code' => '1705204007',
                    'old_code' => '175204007',
                    'name' => 'Campaasan',
                ],
                [
                    'code' => '1705204008',
                    'old_code' => '175204008',
                    'name' => 'Maasin',
                ],
                [
                    'code' => '1705204009',
                    'old_code' => '175204009',
                    'name' => 'Maujao',
                ],
                [
                    'code' => '1705204010',
                    'old_code' => '175204010',
                    'name' => 'Milagrosa',
                ],
                [
                    'code' => '1705204011',
                    'old_code' => '175204011',
                    'name' => 'Nasukob',
                ],
                [
                    'code' => '1705204012',
                    'old_code' => '175204012',
                    'name' => 'Poblacion',
                ],
                [
                    'code' => '1705204013',
                    'old_code' => '175204013',
                    'name' => 'San Francisco',
                ],
                [
                    'code' => '1705204014',
                    'old_code' => '175204014',
                    'name' => 'San Isidro',
                ],
                [
                    'code' => '1705204015',
                    'old_code' => '175204015',
                    'name' => 'San Juan',
                ],
                [
                    'code' => '1705204017',
                    'old_code' => '175204017',
                    'name' => 'San Roque',
                ],
            ],
        ],
        [
            'code' => '1705205000',
            'old_code' => '175205000',
            'name' => 'City of Calapan',
            'is_city' => true,
            'barangays' => [
                [
                    'code' => '1705205001',
                    'old_code' => '175205001',
                    'name' => 'Balingayan',
                ],
                [
                    'code' => '1705205002',
                    'old_code' => '175205002',
                    'name' => 'Balite',
                ],
                [
                    'code' => '1705205003',
                    'old_code' => '175205003',
                    'name' => 'Baruyan',
                ],
                [
                    'code' => '1705205004',
                    'old_code' => '175205004',
                    'name' => 'Batino',
                ],
                [
                    'code' => '1705205005',
                    'old_code' => '175205005',
                    'name' => 'Bayanan I',
                ],
                [
                    'code' => '1705205006',
                    'old_code' => '175205006',
                    'name' => 'Bayanan II',
                ],
                [
                    'code' => '1705205007',
                    'old_code' => '175205007',
                    'name' => 'Biga',
                ],
                [
                    'code' => '1705205008',
                    'old_code' => '175205008',
                    'name' => 'Bondoc',
                ],
                [
                    'code' => '1705205009',
                    'old_code' => '175205009',
                    'name' => 'Bucayao',
                ],
                [
                    'code' => '1705205010',
                    'old_code' => '175205010',
                    'name' => 'Buhuan',
                ],
                [
                    'code' => '1705205011',
                    'old_code' => '175205011',
                    'name' => 'Bulusan',
                ],
                [
                    'code' => '1705205013',
                    'old_code' => '175205013',
                    'name' => 'Calero',
                ],
                [
                    'code' => '1705205015',
                    'old_code' => '175205015',
                    'name' => 'Camansihan',
                ],
                [
                    'code' => '1705205016',
                    'old_code' => '175205016',
                    'name' => 'Camilmil',
                ],
                [
                    'code' => '1705205017',
                    'old_code' => '175205017',
                    'name' => 'Canubing I',
                ],
                [
                    'code' => '1705205018',
                    'old_code' => '175205018',
                    'name' => 'Canubing II',
                ],
                [
                    'code' => '1705205019',
                    'old_code' => '175205019',
                    'name' => 'Comunal',
                ],
                [
                    'code' => '1705205021',
                    'old_code' => '175205021',
                    'name' => 'Guinobatan',
                ],
                [
                    'code' => '1705205022',
                    'old_code' => '175205022',
                    'name' => 'Gulod',
                ],
                [
                    'code' => '1705205023',
                    'old_code' => '175205023',
                    'name' => 'Gutad',
                ],
                [
                    'code' => '1705205025',
                    'old_code' => '175205025',
                    'name' => 'Ibaba East',
                ],
                [
                    'code' => '1705205026',
                    'old_code' => '175205026',
                    'name' => 'Ibaba West',
                ],
                [
                    'code' => '1705205027',
                    'old_code' => '175205027',
                    'name' => 'Ilaya',
                ],
                [
                    'code' => '1705205028',
                    'old_code' => '175205028',
                    'name' => 'Lalud',
                ],
                [
                    'code' => '1705205029',
                    'old_code' => '175205029',
                    'name' => 'Lazareto',
                ],
                [
                    'code' => '1705205030',
                    'old_code' => '175205030',
                    'name' => 'Libis',
                ],
                [
                    'code' => '1705205031',
                    'old_code' => '175205031',
                    'name' => 'Lumangbayan',
                ],
                [
                    'code' => '1705205032',
                    'old_code' => '175205032',
                    'name' => 'Mahal Na Pangalan',
                ],
                [
                    'code' => '1705205033',
                    'old_code' => '175205033',
                    'name' => 'Maidlang',
                ],
                [
                    'code' => '1705205034',
                    'old_code' => '175205034',
                    'name' => 'Malad',
                ],
                [
                    'code' => '1705205035',
                    'old_code' => '175205035',
                    'name' => 'Malamig',
                ],
                [
                    'code' => '1705205036',
                    'old_code' => '175205036',
                    'name' => 'Managpi',
                ],
                [
                    'code' => '1705205037',
                    'old_code' => '175205037',
                    'name' => 'Masipit',
                ],
                [
                    'code' => '1705205038',
                    'old_code' => '175205038',
                    'name' => 'Nag-Iba I',
                ],
                [
                    'code' => '1705205068',
                    'old_code' => '175205068',
                    'name' => 'Nag-Iba II',
                ],
                [
                    'code' => '1705205039',
                    'old_code' => '175205039',
                    'name' => 'Navotas',
                ],
                [
                    'code' => '1705205041',
                    'old_code' => '175205041',
                    'name' => 'Pachoca',
                ],
                [
                    'code' => '1705205042',
                    'old_code' => '175205042',
                    'name' => 'Palhi',
                ],
                [
                    'code' => '1705205043',
                    'old_code' => '175205043',
                    'name' => 'Panggalaan',
                ],
                [
                    'code' => '1705205044',
                    'old_code' => '175205044',
                    'name' => 'Parang',
                ],
                [
                    'code' => '1705205045',
                    'old_code' => '175205045',
                    'name' => 'Patas',
                ],
                [
                    'code' => '1705205046',
                    'old_code' => '175205046',
                    'name' => 'Personas',
                ],
                [
                    'code' => '1705205047',
                    'old_code' => '175205047',
                    'name' => 'Puting Tubig',
                ],
                [
                    'code' => '1705205048',
                    'old_code' => '175205048',
                    'name' => 'Salong',
                ],
                [
                    'code' => '1705205049',
                    'old_code' => '175205049',
                    'name' => 'San Antonio',
                ],
                [
                    'code' => '1705205050',
                    'old_code' => '175205050',
                    'name' => 'San Vicente Central',
                ],
                [
                    'code' => '1705205051',
                    'old_code' => '175205051',
                    'name' => 'San Vicente East',
                ],
                [
                    'code' => '1705205052',
                    'old_code' => '175205052',
                    'name' => 'San Vicente North',
                ],
                [
                    'code' => '1705205053',
                    'old_code' => '175205053',
                    'name' => 'San Vicente South',
                ],
                [
                    'code' => '1705205054',
                    'old_code' => '175205054',
                    'name' => 'San Vicente West',
                ],
                [
                    'code' => '1705205058',
                    'old_code' => '175205058',
                    'name' => 'Sapul',
                ],
                [
                    'code' => '1705205059',
                    'old_code' => '175205059',
                    'name' => 'Silonay',
                ],
                [
                    'code' => '1705205055',
                    'old_code' => '175205055',
                    'name' => 'Sta. Cruz',
                ],
                [
                    'code' => '1705205056',
                    'old_code' => '175205056',
                    'name' => 'Sta. Isabel',
                ],
                [
                    'code' => '1705205061',
                    'old_code' => '175205061',
                    'name' => 'Sta. Maria Village',
                ],
                [
                    'code' => '1705205012',
                    'old_code' => '175205012',
                    'name' => 'Sta. Rita',
                ],
                [
                    'code' => '1705205057',
                    'old_code' => '175205057',
                    'name' => 'Sto. Niño',
                ],
                [
                    'code' => '1705205062',
                    'old_code' => '175205062',
                    'name' => 'Suqui',
                ],
                [
                    'code' => '1705205063',
                    'old_code' => '175205063',
                    'name' => 'Tawagan',
                ],
                [
                    'code' => '1705205064',
                    'old_code' => '175205064',
                    'name' => 'Tawiran',
                ],
                [
                    'code' => '1705205065',
                    'old_code' => '175205065',
                    'name' => 'Tibag',
                ],
                [
                    'code' => '1705205066',
                    'old_code' => '175205066',
                    'name' => 'Wawa',
                ],
            ],
        ],
        [
            'code' => '1705206000',
            'old_code' => '175206000',
            'name' => 'Gloria',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705206002',
                    'old_code' => '175206002',
                    'name' => 'Agos',
                ],
                [
                    'code' => '1705206001',
                    'old_code' => '175206001',
                    'name' => 'Agsalin',
                ],
                [
                    'code' => '1705206029',
                    'old_code' => '175206029',
                    'name' => 'Alma Villa',
                ],
                [
                    'code' => '1705206003',
                    'old_code' => '175206003',
                    'name' => 'Andres Bonifacio',
                ],
                [
                    'code' => '1705206004',
                    'old_code' => '175206004',
                    'name' => 'Balete',
                ],
                [
                    'code' => '1705206005',
                    'old_code' => '175206005',
                    'name' => 'Banus',
                ],
                [
                    'code' => '1705206006',
                    'old_code' => '175206006',
                    'name' => 'Banutan',
                ],
                [
                    'code' => '1705206008',
                    'old_code' => '175206008',
                    'name' => 'Bulaklakan',
                ],
                [
                    'code' => '1705206007',
                    'old_code' => '175206007',
                    'name' => 'Buong Lupa',
                ],
                [
                    'code' => '1705206009',
                    'old_code' => '175206009',
                    'name' => 'Gaudencio Antonino',
                ],
                [
                    'code' => '1705206010',
                    'old_code' => '175206010',
                    'name' => 'Guimbonan',
                ],
                [
                    'code' => '1705206012',
                    'old_code' => '175206012',
                    'name' => 'Kawit',
                ],
                [
                    'code' => '1705206013',
                    'old_code' => '175206013',
                    'name' => 'Lucio Laurel',
                ],
                [
                    'code' => '1705206014',
                    'old_code' => '175206014',
                    'name' => 'Macario Adriatico',
                ],
                [
                    'code' => '1705206015',
                    'old_code' => '175206015',
                    'name' => 'Malamig',
                ],
                [
                    'code' => '1705206016',
                    'old_code' => '175206016',
                    'name' => 'Malayong',
                ],
                [
                    'code' => '1705206017',
                    'old_code' => '175206017',
                    'name' => 'Maligaya',
                ],
                [
                    'code' => '1705206018',
                    'old_code' => '175206018',
                    'name' => 'Malubay',
                ],
                [
                    'code' => '1705206020',
                    'old_code' => '175206020',
                    'name' => 'Manguyang',
                ],
                [
                    'code' => '1705206021',
                    'old_code' => '175206021',
                    'name' => 'Maragooc',
                ],
                [
                    'code' => '1705206022',
                    'old_code' => '175206022',
                    'name' => 'Mirayan',
                ],
                [
                    'code' => '1705206023',
                    'old_code' => '175206023',
                    'name' => 'Narra',
                ],
                [
                    'code' => '1705206024',
                    'old_code' => '175206024',
                    'name' => 'Papandungin',
                ],
                [
                    'code' => '1705206025',
                    'old_code' => '175206025',
                    'name' => 'San Antonio',
                ],
                [
                    'code' => '1705206026',
                    'old_code' => '175206026',
                    'name' => 'Santa Maria',
                ],
                [
                    'code' => '1705206027',
                    'old_code' => '175206027',
                    'name' => 'Santa Theresa',
                ],
                [
                    'code' => '1705206028',
                    'old_code' => '175206028',
                    'name' => 'Tambong',
                ],
            ],
        ],
        [
            'code' => '1705207000',
            'old_code' => '175207000',
            'name' => 'Mansalay',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705207001',
                    'old_code' => '175207001',
                    'name' => 'B. Del Mundo',
                ],
                [
                    'code' => '1705207002',
                    'old_code' => '175207002',
                    'name' => 'Balugo',
                ],
                [
                    'code' => '1705207003',
                    'old_code' => '175207003',
                    'name' => 'Bonbon',
                ],
                [
                    'code' => '1705207004',
                    'old_code' => '175207004',
                    'name' => 'Budburan',
                ],
                [
                    'code' => '1705207005',
                    'old_code' => '175207005',
                    'name' => 'Cabalwa',
                ],
                [
                    'code' => '1705207007',
                    'old_code' => '175207007',
                    'name' => 'Don Pedro',
                ],
                [
                    'code' => '1705207010',
                    'old_code' => '175207010',
                    'name' => 'Maliwanag',
                ],
                [
                    'code' => '1705207011',
                    'old_code' => '175207011',
                    'name' => 'Manaul',
                ],
                [
                    'code' => '1705207012',
                    'old_code' => '175207012',
                    'name' => 'Panaytayan',
                ],
                [
                    'code' => '1705207013',
                    'old_code' => '175207013',
                    'name' => 'Poblacion',
                ],
                [
                    'code' => '1705207014',
                    'old_code' => '175207014',
                    'name' => 'Roma',
                ],
                [
                    'code' => '1705207016',
                    'old_code' => '175207016',
                    'name' => 'Santa Brigida',
                ],
                [
                    'code' => '1705207017',
                    'old_code' => '175207017',
                    'name' => 'Santa Maria',
                ],
                [
                    'code' => '1705207020',
                    'old_code' => '175207020',
                    'name' => 'Santa Teresita',
                ],
                [
                    'code' => '1705207018',
                    'old_code' => '175207018',
                    'name' => 'Villa Celestial',
                ],
                [
                    'code' => '1705207019',
                    'old_code' => '175207019',
                    'name' => 'Wasig',
                ],
                [
                    'code' => '1705207021',
                    'old_code' => '175207021',
                    'name' => 'Waygan',
                ],
            ],
        ],
        [
            'code' => '1705208000',
            'old_code' => '175208000',
            'name' => 'Naujan',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705208001',
                    'old_code' => '175208001',
                    'name' => 'Adrialuna',
                ],
                [
                    'code' => '1705208025',
                    'old_code' => '175208025',
                    'name' => 'Andres Ilagan',
                ],
                [
                    'code' => '1705208002',
                    'old_code' => '175208002',
                    'name' => 'Antipolo',
                ],
                [
                    'code' => '1705208003',
                    'old_code' => '175208003',
                    'name' => 'Apitong',
                ],
                [
                    'code' => '1705208004',
                    'old_code' => '175208004',
                    'name' => 'Arangin',
                ],
                [
                    'code' => '1705208005',
                    'old_code' => '175208005',
                    'name' => 'Aurora',
                ],
                [
                    'code' => '1705208006',
                    'old_code' => '175208006',
                    'name' => 'Bacungan',
                ],
                [
                    'code' => '1705208007',
                    'old_code' => '175208007',
                    'name' => 'Bagong Buhay',
                ],
                [
                    'code' => '1705208068',
                    'old_code' => '175208068',
                    'name' => 'Balite',
                ],
                [
                    'code' => '1705208008',
                    'old_code' => '175208008',
                    'name' => 'Bancuro',
                ],
                [
                    'code' => '1705208069',
                    'old_code' => '175208069',
                    'name' => 'Banuton',
                ],
                [
                    'code' => '1705208010',
                    'old_code' => '175208010',
                    'name' => 'Barcenaga',
                ],
                [
                    'code' => '1705208011',
                    'old_code' => '175208011',
                    'name' => 'Bayani',
                ],
                [
                    'code' => '1705208012',
                    'old_code' => '175208012',
                    'name' => 'Buhangin',
                ],
                [
                    'code' => '1705208070',
                    'old_code' => '175208070',
                    'name' => 'Caburo',
                ],
                [
                    'code' => '1705208013',
                    'old_code' => '175208013',
                    'name' => 'Concepcion',
                ],
                [
                    'code' => '1705208014',
                    'old_code' => '175208014',
                    'name' => 'Dao',
                ],
                [
                    'code' => '1705208015',
                    'old_code' => '175208015',
                    'name' => 'Del Pilar',
                ],
                [
                    'code' => '1705208016',
                    'old_code' => '175208016',
                    'name' => 'Estrella',
                ],
                [
                    'code' => '1705208017',
                    'old_code' => '175208017',
                    'name' => 'Evangelista',
                ],
                [
                    'code' => '1705208018',
                    'old_code' => '175208018',
                    'name' => 'Gamao',
                ],
                [
                    'code' => '1705208019',
                    'old_code' => '175208019',
                    'name' => 'General Esco',
                ],
                [
                    'code' => '1705208020',
                    'old_code' => '175208020',
                    'name' => 'Herrera',
                ],
                [
                    'code' => '1705208021',
                    'old_code' => '175208021',
                    'name' => 'Inarawan',
                ],
                [
                    'code' => '1705208022',
                    'old_code' => '175208022',
                    'name' => 'Kalinisan',
                ],
                [
                    'code' => '1705208023',
                    'old_code' => '175208023',
                    'name' => 'Laguna',
                ],
                [
                    'code' => '1705208024',
                    'old_code' => '175208024',
                    'name' => 'Mabini',
                ],
                [
                    'code' => '1705208071',
                    'old_code' => '175208071',
                    'name' => 'Magtibay',
                ],
                [
                    'code' => '1705208026',
                    'old_code' => '175208026',
                    'name' => 'Mahabang Parang',
                ],
                [
                    'code' => '1705208027',
                    'old_code' => '175208027',
                    'name' => 'Malaya',
                ],
                [
                    'code' => '1705208028',
                    'old_code' => '175208028',
                    'name' => 'Malinao',
                ],
                [
                    'code' => '1705208029',
                    'old_code' => '175208029',
                    'name' => 'Malvar',
                ],
                [
                    'code' => '1705208030',
                    'old_code' => '175208030',
                    'name' => 'Masagana',
                ],
                [
                    'code' => '1705208031',
                    'old_code' => '175208031',
                    'name' => 'Masaguing',
                ],
                [
                    'code' => '1705208032',
                    'old_code' => '175208032',
                    'name' => 'Melgar A',
                ],
                [
                    'code' => '1705208066',
                    'old_code' => '175208066',
                    'name' => 'Melgar B',
                ],
                [
                    'code' => '1705208033',
                    'old_code' => '175208033',
                    'name' => 'Metolza',
                ],
                [
                    'code' => '1705208034',
                    'old_code' => '175208034',
                    'name' => 'Montelago',
                ],
                [
                    'code' => '1705208035',
                    'old_code' => '175208035',
                    'name' => 'Montemayor',
                ],
                [
                    'code' => '1705208036',
                    'old_code' => '175208036',
                    'name' => 'Motoderazo',
                ],
                [
                    'code' => '1705208037',
                    'old_code' => '175208037',
                    'name' => 'Mulawin',
                ],
                [
                    'code' => '1705208038',
                    'old_code' => '175208038',
                    'name' => 'Nag-Iba I',
                ],
                [
                    'code' => '1705208039',
                    'old_code' => '175208039',
                    'name' => 'Nag-Iba II',
                ],
                [
                    'code' => '1705208040',
                    'old_code' => '175208040',
                    'name' => 'Pagkakaisa',
                ],
                [
                    'code' => '1705208072',
                    'old_code' => '175208072',
                    'name' => 'Paitan',
                ],
                [
                    'code' => '1705208042',
                    'old_code' => '175208042',
                    'name' => 'Paniquian',
                ],
                [
                    'code' => '1705208043',
                    'old_code' => '175208043',
                    'name' => 'Pinagsabangan I',
                ],
                [
                    'code' => '1705208044',
                    'old_code' => '175208044',
                    'name' => 'Pinagsabangan II',
                ],
                [
                    'code' => '1705208045',
                    'old_code' => '175208045',
                    'name' => 'Piñahan',
                ],
                [
                    'code' => '1705208046',
                    'old_code' => '175208046',
                    'name' => 'Poblacion I',
                ],
                [
                    'code' => '1705208047',
                    'old_code' => '175208047',
                    'name' => 'Poblacion II',
                ],
                [
                    'code' => '1705208048',
                    'old_code' => '175208048',
                    'name' => 'Poblacion III',
                ],
                [
                    'code' => '1705208049',
                    'old_code' => '175208049',
                    'name' => 'Sampaguita',
                ],
                [
                    'code' => '1705208050',
                    'old_code' => '175208050',
                    'name' => 'San Agustin I',
                ],
                [
                    'code' => '1705208051',
                    'old_code' => '175208051',
                    'name' => 'San Agustin II',
                ],
                [
                    'code' => '1705208052',
                    'old_code' => '175208052',
                    'name' => 'San Andres',
                ],
                [
                    'code' => '1705208053',
                    'old_code' => '175208053',
                    'name' => 'San Antonio',
                ],
                [
                    'code' => '1705208054',
                    'old_code' => '175208054',
                    'name' => 'San Carlos',
                ],
                [
                    'code' => '1705208055',
                    'old_code' => '175208055',
                    'name' => 'San Isidro',
                ],
                [
                    'code' => '1705208056',
                    'old_code' => '175208056',
                    'name' => 'San Jose',
                ],
                [
                    'code' => '1705208057',
                    'old_code' => '175208057',
                    'name' => 'San Luis',
                ],
                [
                    'code' => '1705208058',
                    'old_code' => '175208058',
                    'name' => 'San Nicolas',
                ],
                [
                    'code' => '1705208059',
                    'old_code' => '175208059',
                    'name' => 'San Pedro',
                ],
                [
                    'code' => '1705208067',
                    'old_code' => '175208067',
                    'name' => 'Santa Cruz',
                ],
                [
                    'code' => '1705208060',
                    'old_code' => '175208060',
                    'name' => 'Santa Isabel',
                ],
                [
                    'code' => '1705208061',
                    'old_code' => '175208061',
                    'name' => 'Santa Maria',
                ],
                [
                    'code' => '1705208062',
                    'old_code' => '175208062',
                    'name' => 'Santiago',
                ],
                [
                    'code' => '1705208063',
                    'old_code' => '175208063',
                    'name' => 'Santo Niño',
                ],
                [
                    'code' => '1705208064',
                    'old_code' => '175208064',
                    'name' => 'Tagumpay',
                ],
                [
                    'code' => '1705208065',
                    'old_code' => '175208065',
                    'name' => 'Tigkan',
                ],
            ],
        ],
        [
            'code' => '1705209000',
            'old_code' => '175209000',
            'name' => 'Pinamalayan',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705209001',
                    'old_code' => '175209001',
                    'name' => 'Anoling',
                ],
                [
                    'code' => '1705209002',
                    'old_code' => '175209002',
                    'name' => 'Bacungan',
                ],
                [
                    'code' => '1705209003',
                    'old_code' => '175209003',
                    'name' => 'Bangbang',
                ],
                [
                    'code' => '1705209004',
                    'old_code' => '175209004',
                    'name' => 'Banilad',
                ],
                [
                    'code' => '1705209005',
                    'old_code' => '175209005',
                    'name' => 'Buli',
                ],
                [
                    'code' => '1705209006',
                    'old_code' => '175209006',
                    'name' => 'Cacawan',
                ],
                [
                    'code' => '1705209007',
                    'old_code' => '175209007',
                    'name' => 'Calingag',
                ],
                [
                    'code' => '1705209008',
                    'old_code' => '175209008',
                    'name' => 'Delrazon',
                ],
                [
                    'code' => '1705209037',
                    'old_code' => '175209037',
                    'name' => 'Guinhawa',
                ],
                [
                    'code' => '1705209009',
                    'old_code' => '175209009',
                    'name' => 'Inclanay',
                ],
                [
                    'code' => '1705209010',
                    'old_code' => '175209010',
                    'name' => 'Lumambayan',
                ],
                [
                    'code' => '1705209011',
                    'old_code' => '175209011',
                    'name' => 'Malaya',
                ],
                [
                    'code' => '1705209012',
                    'old_code' => '175209012',
                    'name' => 'Maliangcog',
                ],
                [
                    'code' => '1705209013',
                    'old_code' => '175209013',
                    'name' => 'Maningcol',
                ],
                [
                    'code' => '1705209014',
                    'old_code' => '175209014',
                    'name' => 'Marayos',
                ],
                [
                    'code' => '1705209015',
                    'old_code' => '175209015',
                    'name' => 'Marfrancisco',
                ],
                [
                    'code' => '1705209016',
                    'old_code' => '175209016',
                    'name' => 'Nabuslot',
                ],
                [
                    'code' => '1705209017',
                    'old_code' => '175209017',
                    'name' => 'Pagalagala',
                ],
                [
                    'code' => '1705209018',
                    'old_code' => '175209018',
                    'name' => 'Palayan',
                ],
                [
                    'code' => '1705209019',
                    'old_code' => '175209019',
                    'name' => 'Pambisan Malaki',
                ],
                [
                    'code' => '1705209020',
                    'old_code' => '175209020',
                    'name' => 'Pambisan Munti',
                ],
                [
                    'code' => '1705209021',
                    'old_code' => '175209021',
                    'name' => 'Panggulayan',
                ],
                [
                    'code' => '1705209022',
                    'old_code' => '175209022',
                    'name' => 'Papandayan',
                ],
                [
                    'code' => '1705209023',
                    'old_code' => '175209023',
                    'name' => 'Pili',
                ],
                [
                    'code' => '1705209027',
                    'old_code' => '175209027',
                    'name' => 'Quinabigan',
                ],
                [
                    'code' => '1705209028',
                    'old_code' => '175209028',
                    'name' => 'Ranzo',
                ],
                [
                    'code' => '1705209029',
                    'old_code' => '175209029',
                    'name' => 'Rosario',
                ],
                [
                    'code' => '1705209030',
                    'old_code' => '175209030',
                    'name' => 'Sabang',
                ],
                [
                    'code' => '1705209031',
                    'old_code' => '175209031',
                    'name' => 'Sta. Isabel',
                ],
                [
                    'code' => '1705209032',
                    'old_code' => '175209032',
                    'name' => 'Sta. Maria',
                ],
                [
                    'code' => '1705209033',
                    'old_code' => '175209033',
                    'name' => 'Sta. Rita',
                ],
                [
                    'code' => '1705209036',
                    'old_code' => '175209036',
                    'name' => 'Sto. Niño',
                ],
                [
                    'code' => '1705209034',
                    'old_code' => '175209034',
                    'name' => 'Wawa',
                ],
                [
                    'code' => '1705209035',
                    'old_code' => '175209035',
                    'name' => 'Zone I',
                ],
                [
                    'code' => '1705209024',
                    'old_code' => '175209024',
                    'name' => 'Zone II',
                ],
                [
                    'code' => '1705209025',
                    'old_code' => '175209025',
                    'name' => 'Zone III',
                ],
                [
                    'code' => '1705209026',
                    'old_code' => '175209026',
                    'name' => 'Zone IV',
                ],
            ],
        ],
        [
            'code' => '1705210000',
            'old_code' => '175210000',
            'name' => 'Pola',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705210001',
                    'old_code' => '175210001',
                    'name' => 'Bacawan',
                ],
                [
                    'code' => '1705210002',
                    'old_code' => '175210002',
                    'name' => 'Bacungan',
                ],
                [
                    'code' => '1705210004',
                    'old_code' => '175210004',
                    'name' => 'Batuhan',
                ],
                [
                    'code' => '1705210005',
                    'old_code' => '175210005',
                    'name' => 'Bayanan',
                ],
                [
                    'code' => '1705210006',
                    'old_code' => '175210006',
                    'name' => 'Biga',
                ],
                [
                    'code' => '1705210007',
                    'old_code' => '175210007',
                    'name' => 'Buhay Na Tubig',
                ],
                [
                    'code' => '1705210009',
                    'old_code' => '175210009',
                    'name' => 'Calima',
                ],
                [
                    'code' => '1705210008',
                    'old_code' => '175210008',
                    'name' => 'Calubasanhon',
                ],
                [
                    'code' => '1705210024',
                    'old_code' => '175210024',
                    'name' => 'Campamento',
                ],
                [
                    'code' => '1705210010',
                    'old_code' => '175210010',
                    'name' => 'Casiligan',
                ],
                [
                    'code' => '1705210011',
                    'old_code' => '175210011',
                    'name' => 'Malibago',
                ],
                [
                    'code' => '1705210012',
                    'old_code' => '175210012',
                    'name' => 'Maluanluan',
                ],
                [
                    'code' => '1705210013',
                    'old_code' => '175210013',
                    'name' => 'Matulatula',
                ],
                [
                    'code' => '1705210025',
                    'old_code' => '175210025',
                    'name' => 'Misong',
                ],
                [
                    'code' => '1705210014',
                    'old_code' => '175210014',
                    'name' => 'Pahilahan',
                ],
                [
                    'code' => '1705210015',
                    'old_code' => '175210015',
                    'name' => 'Panikihan',
                ],
                [
                    'code' => '1705210019',
                    'old_code' => '175210019',
                    'name' => 'Pula',
                ],
                [
                    'code' => '1705210020',
                    'old_code' => '175210020',
                    'name' => 'Puting Cacao',
                ],
                [
                    'code' => '1705210021',
                    'old_code' => '175210021',
                    'name' => 'Tagbakin',
                ],
                [
                    'code' => '1705210022',
                    'old_code' => '175210022',
                    'name' => 'Tagumpay',
                ],
                [
                    'code' => '1705210023',
                    'old_code' => '175210023',
                    'name' => 'Tiguihan',
                ],
                [
                    'code' => '1705210017',
                    'old_code' => '175210017',
                    'name' => 'Zone I',
                ],
                [
                    'code' => '1705210018',
                    'old_code' => '175210018',
                    'name' => 'Zone II',
                ],
            ],
        ],
        [
            'code' => '1705211000',
            'old_code' => '175211000',
            'name' => 'Puerto Galera',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705211001',
                    'old_code' => '175211001',
                    'name' => 'Aninuan',
                ],
                [
                    'code' => '1705211013',
                    'old_code' => '175211013',
                    'name' => 'Baclayan',
                ],
                [
                    'code' => '1705211002',
                    'old_code' => '175211002',
                    'name' => 'Balatero',
                ],
                [
                    'code' => '1705211003',
                    'old_code' => '175211003',
                    'name' => 'Dulangan',
                ],
                [
                    'code' => '1705211004',
                    'old_code' => '175211004',
                    'name' => 'Palangan',
                ],
                [
                    'code' => '1705211012',
                    'old_code' => '175211012',
                    'name' => 'Poblacion',
                ],
                [
                    'code' => '1705211005',
                    'old_code' => '175211005',
                    'name' => 'Sabang',
                ],
                [
                    'code' => '1705211006',
                    'old_code' => '175211006',
                    'name' => 'San Antonio',
                ],
                [
                    'code' => '1705211007',
                    'old_code' => '175211007',
                    'name' => 'San Isidro',
                ],
                [
                    'code' => '1705211008',
                    'old_code' => '175211008',
                    'name' => 'Santo Niño',
                ],
                [
                    'code' => '1705211009',
                    'old_code' => '175211009',
                    'name' => 'Sinandigan',
                ],
                [
                    'code' => '1705211010',
                    'old_code' => '175211010',
                    'name' => 'Tabinay',
                ],
                [
                    'code' => '1705211011',
                    'old_code' => '175211011',
                    'name' => 'Villaflor',
                ],
            ],
        ],
        [
            'code' => '1705212000',
            'old_code' => '175212000',
            'name' => 'Roxas',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705212001',
                    'old_code' => '175212001',
                    'name' => 'Bagumbayan',
                ],
                [
                    'code' => '1705212002',
                    'old_code' => '175212002',
                    'name' => 'Cantil',
                ],
                [
                    'code' => '1705212003',
                    'old_code' => '175212003',
                    'name' => 'Dangay',
                ],
                [
                    'code' => '1705212004',
                    'old_code' => '175212004',
                    'name' => 'Happy Valley',
                ],
                [
                    'code' => '1705212005',
                    'old_code' => '175212005',
                    'name' => 'Libertad',
                ],
                [
                    'code' => '1705212006',
                    'old_code' => '175212006',
                    'name' => 'Libtong',
                ],
                [
                    'code' => '1705212020',
                    'old_code' => '175212020',
                    'name' => 'Little Tanauan',
                ],
                [
                    'code' => '1705212007',
                    'old_code' => '175212007',
                    'name' => 'Mabuhay',
                ],
                [
                    'code' => '1705212008',
                    'old_code' => '175212008',
                    'name' => 'Maraska',
                ],
                [
                    'code' => '1705212009',
                    'old_code' => '175212009',
                    'name' => 'Odiong',
                ],
                [
                    'code' => '1705212010',
                    'old_code' => '175212010',
                    'name' => 'Paclasan',
                ],
                [
                    'code' => '1705212011',
                    'old_code' => '175212011',
                    'name' => 'San Aquilino',
                ],
                [
                    'code' => '1705212012',
                    'old_code' => '175212012',
                    'name' => 'San Isidro',
                ],
                [
                    'code' => '1705212013',
                    'old_code' => '175212013',
                    'name' => 'San Jose',
                ],
                [
                    'code' => '1705212014',
                    'old_code' => '175212014',
                    'name' => 'San Mariano',
                ],
                [
                    'code' => '1705212015',
                    'old_code' => '175212015',
                    'name' => 'San Miguel',
                ],
                [
                    'code' => '1705212016',
                    'old_code' => '175212016',
                    'name' => 'San Rafael',
                ],
                [
                    'code' => '1705212017',
                    'old_code' => '175212017',
                    'name' => 'San Vicente',
                ],
                [
                    'code' => '1705212018',
                    'old_code' => '175212018',
                    'name' => 'Uyao',
                ],
                [
                    'code' => '1705212019',
                    'old_code' => '175212019',
                    'name' => 'Victoria',
                ],
            ],
        ],
        [
            'code' => '1705213000',
            'old_code' => '175213000',
            'name' => 'San Teodoro',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705213001',
                    'old_code' => '175213001',
                    'name' => 'Bigaan',
                ],
                [
                    'code' => '1705213008',
                    'old_code' => '175213008',
                    'name' => 'Caagutayan',
                ],
                [
                    'code' => '1705213002',
                    'old_code' => '175213002',
                    'name' => 'Calangatan',
                ],
                [
                    'code' => '1705213003',
                    'old_code' => '175213003',
                    'name' => 'Calsapa',
                ],
                [
                    'code' => '1705213004',
                    'old_code' => '175213004',
                    'name' => 'Ilag',
                ],
                [
                    'code' => '1705213005',
                    'old_code' => '175213005',
                    'name' => 'Lumangbayan',
                ],
                [
                    'code' => '1705213007',
                    'old_code' => '175213007',
                    'name' => 'Poblacion',
                ],
                [
                    'code' => '1705213006',
                    'old_code' => '175213006',
                    'name' => 'Tacligan',
                ],
            ],
        ],
        [
            'code' => '1705214000',
            'old_code' => '175214000',
            'name' => 'Socorro',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705214001',
                    'old_code' => '175214001',
                    'name' => 'Bagsok',
                ],
                [
                    'code' => '1705214002',
                    'old_code' => '175214002',
                    'name' => 'Batong Dalig',
                ],
                [
                    'code' => '1705214003',
                    'old_code' => '175214003',
                    'name' => 'Bayuin',
                ],
                [
                    'code' => '1705214027',
                    'old_code' => '175214027',
                    'name' => 'Bugtong Na Tuog',
                ],
                [
                    'code' => '1705214005',
                    'old_code' => '175214005',
                    'name' => 'Calocmoy',
                ],
                [
                    'code' => '1705214010',
                    'old_code' => '175214010',
                    'name' => 'Calubayan',
                ],
                [
                    'code' => '1705214006',
                    'old_code' => '175214006',
                    'name' => 'Catiningan',
                ],
                [
                    'code' => '1705214008',
                    'old_code' => '175214008',
                    'name' => 'Fortuna',
                ],
                [
                    'code' => '1705214009',
                    'old_code' => '175214009',
                    'name' => 'Happy Valley',
                ],
                [
                    'code' => '1705214012',
                    'old_code' => '175214012',
                    'name' => 'Leuteboro I',
                ],
                [
                    'code' => '1705214013',
                    'old_code' => '175214013',
                    'name' => 'Leuteboro II',
                ],
                [
                    'code' => '1705214029',
                    'old_code' => '175214029',
                    'name' => 'Ma. Concepcion',
                ],
                [
                    'code' => '1705214014',
                    'old_code' => '175214014',
                    'name' => 'Mabuhay I',
                ],
                [
                    'code' => '1705214028',
                    'old_code' => '175214028',
                    'name' => 'Mabuhay II',
                ],
                [
                    'code' => '1705214015',
                    'old_code' => '175214015',
                    'name' => 'Malugay',
                ],
                [
                    'code' => '1705214016',
                    'old_code' => '175214016',
                    'name' => 'Matungao',
                ],
                [
                    'code' => '1705214017',
                    'old_code' => '175214017',
                    'name' => 'Monteverde',
                ],
                [
                    'code' => '1705214018',
                    'old_code' => '175214018',
                    'name' => 'Pasi I',
                ],
                [
                    'code' => '1705214019',
                    'old_code' => '175214019',
                    'name' => 'Pasi II',
                ],
                [
                    'code' => '1705214024',
                    'old_code' => '175214024',
                    'name' => 'Santo Domingo',
                ],
                [
                    'code' => '1705214025',
                    'old_code' => '175214025',
                    'name' => 'Subaan',
                ],
                [
                    'code' => '1705214007',
                    'old_code' => '175214007',
                    'name' => 'Villareal',
                ],
                [
                    'code' => '1705214020',
                    'old_code' => '175214020',
                    'name' => 'Zone I',
                ],
                [
                    'code' => '1705214021',
                    'old_code' => '175214021',
                    'name' => 'Zone II',
                ],
                [
                    'code' => '1705214022',
                    'old_code' => '175214022',
                    'name' => 'Zone III',
                ],
                [
                    'code' => '1705214023',
                    'old_code' => '175214023',
                    'name' => 'Zone IV',
                ],
            ],
        ],
        [
            'code' => '1705215000',
            'old_code' => '175215000',
            'name' => 'Victoria',
            'is_city' => false,
            'barangays' => [
                [
                    'code' => '1705215001',
                    'old_code' => '175215001',
                    'name' => 'Alcate',
                ],
                [
                    'code' => '1705215038',
                    'old_code' => '175215038',
                    'name' => 'Antonino',
                ],
                [
                    'code' => '1705215002',
                    'old_code' => '175215002',
                    'name' => 'Babangonan',
                ],
                [
                    'code' => '1705215004',
                    'old_code' => '175215004',
                    'name' => 'Bagong Buhay',
                ],
                [
                    'code' => '1705215003',
                    'old_code' => '175215003',
                    'name' => 'Bagong Silang',
                ],
                [
                    'code' => '1705215005',
                    'old_code' => '175215005',
                    'name' => 'Bambanin',
                ],
                [
                    'code' => '1705215006',
                    'old_code' => '175215006',
                    'name' => 'Bethel',
                ],
                [
                    'code' => '1705215007',
                    'old_code' => '175215007',
                    'name' => 'Canaan',
                ],
                [
                    'code' => '1705215008',
                    'old_code' => '175215008',
                    'name' => 'Concepcion',
                ],
                [
                    'code' => '1705215009',
                    'old_code' => '175215009',
                    'name' => 'Duongan',
                ],
                [
                    'code' => '1705215036',
                    'old_code' => '175215036',
                    'name' => 'Jose Leido Jr.',
                ],
                [
                    'code' => '1705215010',
                    'old_code' => '175215010',
                    'name' => 'Loyal',
                ],
                [
                    'code' => '1705215011',
                    'old_code' => '175215011',
                    'name' => 'Mabini',
                ],
                [
                    'code' => '1705215012',
                    'old_code' => '175215012',
                    'name' => 'Macatoc',
                ],
                [
                    'code' => '1705215013',
                    'old_code' => '175215013',
                    'name' => 'Malabo',
                ],
                [
                    'code' => '1705215015',
                    'old_code' => '175215015',
                    'name' => 'Merit',
                ],
                [
                    'code' => '1705215016',
                    'old_code' => '175215016',
                    'name' => 'Ordovilla',
                ],
                [
                    'code' => '1705215017',
                    'old_code' => '175215017',
                    'name' => 'Pakyas',
                ],
                [
                    'code' => '1705215018',
                    'old_code' => '175215018',
                    'name' => 'Poblacion I',
                ],
                [
                    'code' => '1705215019',
                    'old_code' => '175215019',
                    'name' => 'Poblacion II',
                ],
                [
                    'code' => '1705215020',
                    'old_code' => '175215020',
                    'name' => 'Poblacion III',
                ],
                [
                    'code' => '1705215021',
                    'old_code' => '175215021',
                    'name' => 'Poblacion IV',
                ],
                [
                    'code' => '1705215027',
                    'old_code' => '175215027',
                    'name' => 'Sampaguita',
                ],
                [
                    'code' => '1705215028',
                    'old_code' => '175215028',
                    'name' => 'San Antonio',
                ],
                [
                    'code' => '1705215037',
                    'old_code' => '175215037',
                    'name' => 'San Cristobal',
                ],
                [
                    'code' => '1705215029',
                    'old_code' => '175215029',
                    'name' => 'San Gabriel',
                ],
                [
                    'code' => '1705215030',
                    'old_code' => '175215030',
                    'name' => 'San Gelacio',
                ],
                [
                    'code' => '1705215031',
                    'old_code' => '175215031',
                    'name' => 'San Isidro',
                ],
                [
                    'code' => '1705215032',
                    'old_code' => '175215032',
                    'name' => 'San Juan',
                ],
                [
                    'code' => '1705215033',
                    'old_code' => '175215033',
                    'name' => 'San Narciso',
                ],
                [
                    'code' => '1705215034',
                    'old_code' => '175215034',
                    'name' => 'Urdaneta',
                ],
                [
                    'code' => '1705215035',
                    'old_code' => '175215035',
                    'name' => 'Villa Cerveza',
                ],
            ],
        ],
    ],
];
